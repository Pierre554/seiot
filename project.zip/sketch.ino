int ledr = 8;
int ledy = 9;
int ledg = 10;

void setup() {
  // put your setup code here, to run once:
 Serial.begin(9600);
 pinMode(ledr, OUTPUT);
 pinMode(ledy, OUTPUT);
 pinMode(ledg, OUTPUT);
}

void loop() {
 digitalWrite(ledr, HIGH);
 digitalWrite(ledy, LOW);
 digitalWrite(ledg, LOW);
 Serial.print("vermelho");
 delay(3000);
 digitalWrite(ledr, LOW);
 digitalWrite(ledy, HIGH);
 digitalWrite(ledg, LOW);
 Serial.print("vermelho");
 delay(3000);
 digitalWrite(ledr, LOW);
 digitalWrite(ledy, LOW);
 digitalWrite(ledg, HIGH);
 Serial.print("vermelho");
 delay(3000);
}